<?php

namespace Pterodactyl\Exceptions\Service\Egg;

use Pterodactyl\Exceptions\DisplayException;

class NoParentConfigurationFoundException extends DisplayException
{
}
